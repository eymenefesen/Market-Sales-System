🛒 Market Sales System – Python Console App
This Python project is a basic stock and sales management system developed for small markets or retail points. With this console-based application, users can add products, perform sales, track stock, and view total profit.

🚀 Features
📦 Add Product: Allows defining new products with details like name, barcode, price, purchase price, stock, and unit.
💰 Sales Operation: Sells product by barcode, updates stock, and calculates profit.
📊 Stock Tracking: View current stock levels.
🔍 Product Search: Search product details by barcode.
➕ Stock Update: Add more stock to an existing product.
💵 Price Update: Change both sale and purchase prices.
📈 Profit Calculation: Shows total profit earned from all sales.
📋 Product List: Displays all products with full details.

⚙️ Usage
When the code runs, users are presented with the following options:

1 → Make a Sale  
2 → Add Product  
3 → Stock Tracking  
4 → Search Product  
5 → Add Stock  
6 → Update Price  
7 → Show Profit  
8 → List Products  
Each operation collects input from the user and processes it using class methods.

💡 Notes
Fully built using Python class structure.

Products are stored at the class level and accessed through that.

Supports both unit-based and weight-based (kg) stock tracking.

Ideal for educational and small-scale projects.

📌 Requirements
This project only runs with Python 3. No external libraries required.

